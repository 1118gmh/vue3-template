var s="./assets/finishPay.dedc5a4e.jpg";export{s as _};
